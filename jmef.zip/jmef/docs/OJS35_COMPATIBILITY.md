# OJS 3.5 Compatibility Notes

- Removed deprecated HANDLER_CLASS injection
- Updated LoadHandler implementation
- Fixed locale compatibility
- Fixed Diamond OA license validation
- Updated routing behaviour for JMEF endpoint
